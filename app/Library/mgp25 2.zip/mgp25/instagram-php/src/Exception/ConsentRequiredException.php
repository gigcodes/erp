<?php

namespace InstagramAPI\Exception;

class ConsentRequiredException extends RequestException
{
}
