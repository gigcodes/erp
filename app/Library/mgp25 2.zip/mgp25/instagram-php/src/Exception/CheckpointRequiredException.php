<?php

namespace InstagramAPI\Exception;

class CheckpointRequiredException extends RequestException
{
}
