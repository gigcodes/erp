<?php

namespace InstagramAPI\Exception;

class FeedbackRequiredException extends RequestException
{
}
