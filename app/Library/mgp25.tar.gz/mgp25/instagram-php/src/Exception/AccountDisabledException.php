<?php

namespace InstagramAPI\Exception;

class AccountDisabledException extends RequestException
{
}
