@extends('layouts.app')

@section('title', 'Old')

@section('content')
@include('partials.flash_messages')
<div class="row">
    <div class="col-lg-12 margin-tb">
		<h2 class="page-heading">Old</h2>
		<div class="pull-left">
			<form action="{{ route('filteredOld') }}" method="GET" class="form-inline align-items-start">
				<div class="form-group mr-3">
					{!! Form::text('sr_no', !empty($_GET['sr_no']) ? $_GET['sr_no'] : '', array('class' => 'form-control', 'placeholder' => 'Serial Number')) !!}
				</div>
				<div class="form-group mr-3">
					{!! Form::select('status', $status, !empty($_GET['status']) ? $_GET['status'] : '', ['class' => 'form-control', 'placeholder'=> 'Status']) !!}
				</div>
				<button type="submit" class="btn btn-image"><img src="/images/filter.png" /></button>
			</form>
		</div>
		<div class="pull-right">
			<button data-toggle="modal" data-target="#createOldInComingModal" class="btn btn-image set-reminder">
				<img src="{{ asset('images/add.png') }}" alt=""  style="width: 18px;">
			</button>
		</div>
	</div>
</div>
   

<div class="table-responsive mt-3">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Sr. No.</th>
            <th scope="col">Name</th>
            <th scope="col" width="30%">Description</th>
            <th scope="col">Amount</th>
            <th scope="col" width="15%">Commitment</th>
            <th scope="col" width="30%">Send Message</th>
            <th scope="col" width="30%">Communication</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>

            
          </tr>
        </thead>
        <tbody>
			@if (!empty($old))
				@foreach ($old as $key => $incoming)
					<tr>
					<th scope="row">{{$incoming->serial_no}}</th>
					<td><a href="{{route('editOld', ['serial_no' => $incoming->serial_no])}}">
            {{$incoming->name}}
             @if($incoming->number)
                        <div>
                            <button type="button" class="btn btn-image call-twilio" data-context="incoming" data-id="{{ $incoming->serial_no }}" data-phone="{{ $incoming->number }}"><img src="/images/call.png"/>
                            </button>
                             @if ($incoming->is_blocked == 1)
                                <button type="button" class="btn btn-image block-twilio" data-id="{{ $incoming->serial_no }}"><img src="/images/blocked-twilio.png"/></button>
                            @else
                                <button type="button" class="btn btn-image block-twilio" data-id="{{ $incoming->serial_no }}"><img src="/images/unblocked-twilio.png"/></button>
                            @endif
                        
                        </div>
                    @endif
          </a></td>
					<td>@php echo htmlspecialchars_decode(stripslashes(str_limit($incoming->description, 50, '<a href="javascript:void(0)">...</a>'))); @endphp
                        @if (strlen(strip_tags($incoming->description)) > 50)
                         <div>
                            <div class="panel-group">
                              <div class="panel panel-default">
                                <div class="panel-heading">
                                  <h4 class="panel-title">
                                    <a data-toggle="collapse" href="#collapse_desc{{$key}}" class="collapsed" aria-expanded="false">Read More</a>
                                  </h4>
                                </div>
                                <div id="collapse_desc{{$key}}" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                  <div class="panel-body">
                                    <div class="messageList" id="message_list_310">
                                        {{$incoming->description}}     
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        @endif
                    </td>
                    <td>{{$incoming->amount}}</td>
                    <td>@php echo htmlspecialchars_decode(stripslashes(str_limit($incoming->commitment, 50, '<a href="javascript:void(0)">...</a>'))); @endphp
                        @if (strlen(strip_tags($incoming->commitment)) > 50)
                         <div>
                            <div class="panel-group">
                              <div class="panel panel-default">
                                <div class="panel-heading">
                                  <h4 class="panel-title">
                                    <a data-toggle="collapse" href="#collapse_commit{{$key}}" class="collapsed" aria-expanded="false">Read More</a>
                                  </h4>
                                </div>
                                <div id="collapse_commit{{$key}}" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                  <div class="panel-body">
                                    <div class="messageList" id="message_list_310">
                                        {{$incoming->commitment}}     
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        @endif
                    </td>
					<td>
                     <div class="d-flex">
                        <input type="text" class="form-control quick-message-field" name="message"
                               placeholder="Message" value="">
                        <button class="btn btn-sm btn-image send-message" data-oldID="{{ $incoming->serial_no }}"><img
                                    src="/images/filled-sent.png"/></button>
                      </div>
                     </td>
                     <td>
                            <button type="button" class="btn btn-xs btn-image load-communication-modal" data-object="old" data-id="{{ $incoming->serial_no }}" title="Load messages"><img src="/images/chat.png" alt=""></button>

                            <ul class="more-communication-container">
                            </ul>
                            <button type="button" class="btn btn-image sendEmail" data-id="10"><img src="/images/customer-email.png"></button>
                    </td>
					<td>{{$incoming->status}}</td>
                    <td>
                            

                            <a class="btn btn-image" href="{{route('editOld', ['serial_no' => $incoming->serial_no])}}" target="_blank"><img src="/images/edit.png"></a>
                            
                            <form method="POST" action="http://sololux-erp.test/customer/3389/destroy" accept-charset="UTF-8" style="display:inline"><input name="_method" type="hidden" value="DELETE"><input name="_token" type="hidden" value="QcS7uP4wjB1kB3etGBmwACpGCttL1GOjj095EMM0">
                            <button type="submit" class="btn btn-image"><img src="/images/delete.png"></button>
                            </form>
                            <td>
                       
					</tr>
				@endforeach
			@endif
        </tbody>
      </table>
</div>
<div class="text-center">
    <div class="text-center">
        {!! $old->links() !!}
    </div>
</div>
<div id="createOldInComingModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
  
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Create</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
  
        <form action="{{ route('storeOld') }}" method="POST">
          @csrf
          <div class="modal-body">
            <div class="form-group">
                {!! Form::text('name', null, ['class' => 'form-control'.($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name']) !!}
                @if ($errors->has('name'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('name') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::textarea('description', null, ['class' => 'form-control'.($errors->has('description') ? ' is-invalid' : ''), 'placeholder' => 'Description']) !!}
				@if ($errors->has('description'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('description') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::number('amount', null,['min' => '0','class' => 'form-control'.($errors->has('amount') ? ' is-invalid' : ''), 'placeholder' => 'Amount']) !!}
				@if ($errors->has('amount'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('amount') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::textarea('commitment', null, ['class' => 'form-control'.($errors->has('commitment') ? ' is-invalid' : ''), 'placeholder' => 'Commitment']) !!}
				@if ($errors->has('commitment'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('commitment') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::textarea('communication', null, ['class' => 'form-control'.($errors->has('communication') ? ' is-invalid' : ''), 'placeholder' => 'Communication']) !!}
				@if ($errors->has('communication'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('communication') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::select('status', $status, null, ['class' => 'form-control'.($errors->has('status') ? ' is-invalid' : ''), 'placeholder' => 'Select Status']) !!}
				@if ($errors->has('status'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('status') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::email('email', null, ['class' => 'form-control'.($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email']) !!}
				@if ($errors->has('email'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::text('number', null, ['class' => 'form-control'.($errors->has('number') ? ' is-invalid' : ''), 'placeholder' => 'Number']) !!}
				@if ($errors->has('number'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('number') }}</strong>
                    </span>
                @endif
            </div>
            <div class="form-group">
				{!! Form::text('address', null, ['class' => 'form-control'.($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address']) !!}
				@if ($errors->has('address'))
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $errors->first('address') }}</strong>
                    </span>
                @endif
            </div>
          </div>
  
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-secondary">Create</button>
          </div>
        </form>
      </div>
    </div>
</div>
 @include('old.partials.modal-email')
  @endsection

@section('scripts')
<script type="text/javascript">
   $(document).on('click', '.block-twilio', function () {
            var old_id = $(this).data('id');
            var thiss = $(this);

            $.ajax({
                type: "POST",
                url: "{{ route('old.block') }}",
                data: {
                    _token: "{{ csrf_token() }}",
                    old_id: old_id
                },
                beforeSend: function () {
                    $(thiss).text('Blocking...');
                }
            }).done(function (response) {
                if (response.is_blocked == 1) {
                    $(thiss).html('<img src="/images/blocked-twilio.png" />');
                } else {
                    $(thiss).html('<img src="/images/unblocked-twilio.png" />');
                }
            }).fail(function (response) {
                $(thiss).html('<img src="/images/unblocked-twilio.png" />');

                alert('Could not block Old Vendor!');

                console.log(response);
            });
        });

   $(document).on('click', '.send-message', function () {
    
            var thiss = $(this);
            var data = new FormData();
            var old_id = 1;
            console.log(old_id);
            alert(old_id);
            var message = $(this).siblings('input').val();

            data.append("old_id", old_id);
            data.append("message", message);
            data.append("status", 1);

            if (message.length > 0) {
                if (!$(thiss).is(':disabled')) {
                    $.ajax({
                        url: '/whatsapp/sendMessage/old',
                        type: 'POST',
                        "dataType": 'json',           // what to expect back from the PHP script, if anything
                        "cache": false,
                        "contentType": false,
                        "processData": false,
                        "data": data,
                        beforeSend: function () {
                            $(thiss).attr('disabled', true);
                        }
                    }).done(function (response) {
                        $(thiss).siblings('input').val('');

                        $(thiss).attr('disabled', false);
                    }).fail(function (errObj) {
                        $(thiss).attr('disabled', false);

                        alert("Could not send message");
                        console.log(errObj);
                    });
                }
            } else {
                alert('Please enter a message first');
            }
        });

   $(document).on('click', '.load-more-communication', function () {
            var thiss = $(this);
            var old_id = $(this).data('id');

            $.ajax({
                type: "GET",
                url: "{{ url('customers') }}/" + customer_id + '/loadMoreMessages',
                data: {
                    old_id: old_id,
                    limit: 30
                },
                beforeSend: function () {
                    //$(thiss).text('Loading...');
                }
            }).done(function (response) {
                var li = "<ul>";
                (response.messages).forEach(function (index) {
                    li += '<li>' + index + '</li>';

                    //$(thiss).closest('td').find('.more-communication-container').append(li);
                });

                li += "</ul>";

                $("#chat-list-history").find(".modal-body").html(li);
                4
                $(thiss).html("<img src='/images/chat.png' alt=''>");
                $("#chat-list-history").modal("show");

            }).fail(function (response) {
                $(thiss).text('Load More');

                alert('Could not load more messages');

                console.log(response);
            });
        });

   $(document).ready(function() {
            $('.sendEmail').on('click', function(e) {
                e.preventDefault(e);
                id = $(this).attr("data-id");
                $('#old_id').val(id);
                $("#sendEmailModal").modal();
            });
        });

   // cc

        $(document).on('click', '.add-cc', function (e) {
            e.preventDefault();

            if ($('#cc-label').is(':hidden')) {
                $('#cc-label').fadeIn();
            }

            var el = `<div class="row cc-input">
            <div class="col-md-10">
                <input type="text" name="cc[]" class="form-control mb-3">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-image cc-delete-button"><img src="/images/delete.png"></button>
            </div>
        </div>`;

            $('#cc-list').append(el);
        });

        $(document).on('click', '.cc-delete-button', function (e) {
            e.preventDefault();
            var parent = $(this).parent().parent();

            parent.hide(300, function () {
                parent.remove();
                var n = 0;

                $('.cc-input').each(function () {
                    n++;
                });

                if (n == 0) {
                    $('#cc-label').fadeOut();
                }
            });
        });

        // bcc

        $(document).on('click', '.add-bcc', function (e) {
            e.preventDefault();

            if ($('#bcc-label').is(':hidden')) {
                $('#bcc-label').fadeIn();
            }

            var el = `<div class="row bcc-input">
            <div class="col-md-10">
                <input type="text" name="bcc[]" class="form-control mb-3">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-image bcc-delete-button"><img src="/images/delete.png"></button>
            </div>
        </div>`;

            $('#bcc-list').append(el);
        });

        $(document).on('click', '.bcc-delete-button', function (e) {
            e.preventDefault();
            var parent = $(this).parent().parent();

            parent.hide(300, function () {
                parent.remove();
                var n = 0;

                $('.bcc-input').each(function () {
                    n++;
                });

                if (n == 0) {
                    $('#bcc-label').fadeOut();
                }
            });
        });

   </script>
@endsection  